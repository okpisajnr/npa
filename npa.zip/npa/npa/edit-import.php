<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location:index.php"); 
    }
    else{

$stid=intval($_GET['stid']);
if(isset($_POST['submit']))
{
$state=$_POST['state'];
$status=$_POST['status'];
$Current=$_POST['Current'];

$sql="update package set status=:status,state=:state,CuLoc=:Current where id=:stid ";
$query = $dbh->prepare($sql);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->bindParam(':state',$state,PDO::PARAM_STR);
$query->bindParam(':Current',$Current,PDO::PARAM_STR);
$query->bindParam(':stid',$stid,PDO::PARAM_STR);
$query->execute();

$msg="Package info updated successfully";
}


?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    	<meta name="viewport" content="width=device-width, initial-scale=1">
        <title>NPA Admin| Edit Import < </title>
        <link rel="stylesheet" href="css/bootstrap.min.css" media="screen" >
        <link rel="stylesheet" href="css/font-awesome.min.css" media="screen" >
        <link rel="stylesheet" href="css/animate-css/animate.min.css" media="screen" >
        <link rel="stylesheet" href="css/lobipanel/lobipanel.min.css" media="screen" >
        <link rel="stylesheet" href="css/prism/prism.css" media="screen" >
        <link rel="stylesheet" href="css/select2/select2.min.css" >
        <link rel="stylesheet" href="css/main.css" media="screen" >
        <script src="js/modernizr/modernizr.min.js"></script>
    </head>
    <body class="top-navbar-fixed">
        <div class="main-wrapper">

            <!-- ========== TOP NAVBAR ========== -->
  <?php include('includes/topbar.php');?> 
            <!-- ========== WRAPPER FOR BOTH SIDEBARS & MAIN CONTENT ========== -->
            <div class="content-wrapper">
                <div class="content-container">

                    <!-- ========== LEFT SIDEBAR ========== -->
                   <?php include('includes/leftbar.php');?>  
                    <!-- /.left-sidebar -->

                    <div class="main-page">

                     <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title">Customer Import</h2>
                                
                                </div>
                                
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li><a href="dashboard.php"><i class="fa fa-home"></i> Home</a></li>
                                
                                        <li class="active">Customer Importation Update</li>
                                    </ul>
                                </div>
                             
                            </div>
                            <!-- /.row -->
                        </div>
                        <div class="container-fluid">
                           
                        <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5>Update Current Status</h5>
                                                </div>
                                            </div>
                                            <div class="panel-body">
<?php if($msg){?>
<div class="alert alert-success left-icon-alert alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert">&times;</button><?php echo htmlentities($msg); ?>
 </div><?php } 
else if($error){?>
    <div class="alert alert-danger left-icon-alert alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert">&times;</button>                                        <strong>Oh snap!</strong> <?php echo htmlentities($error); ?>
                                        </div>
                                        <?php } ?>
                                                <form class="form-horizontal" method="post">
<?php 
$sql = "SELECT * from package where id=:stid";
$query = $dbh->prepare($sql);
$query->bindParam(':stid',$stid,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{  ?>


<div class="form-group">
<label for="default" class="col-sm-2 control-label">email</label>
<div class="col-sm-10">
<input type="text"  class="form-control" id="fullanme" value="<?php echo htmlentities($result->email)?>" readonly="" autocomplete="off">
</div>
</div>

<div class="form-group">
<label for="default" class="col-sm-2 control-label">TrackId</label>
<div class="col-sm-10">
<input type="email" " class="form-control" id="email" value="<?php echo htmlentities($result->TrackId)?>" readonly="" autocomplete="off">
</div>
</div>

<div class="form-group">
     <label for="default" class="col-sm-2 control-label">Coming From</label>
               <div class="col-sm-10">
<input type="text" class="form-control" id="classname" value="<?php echo htmlentities($result->ComingFrom)?>" readonly>
                                                        </div>
                                                    </div>
<div class="form-group">
                                                     

 <label for="date" class="col-sm-2 control-label">Destination</label>
                                                        <div class="col-sm-10"> 
                <input type="text"   class="form-control" value="<?php echo htmlentities($result->GoingTo)?>" id="date" readonly="">
                                                        </div>
                                                    </div>




<div class="form-group">
<label for="default" class="col-sm-2 control-label">Cuurent Location</label>
<div class="col-sm-10">
<input type="text" value="<?php echo htmlentities($result->CuLoc)?>" name="OldCurrent" class="form-control" id="email"  readonly="" autocomplete="on">

<select name="Current" class="form-control" id="default">
<option value="">Select a the current Port</option>
<?php $sql = "SELECT * from seaport where ";
$query = $dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
foreach($results as $result)
{   ?>
<option value="<?php echo htmlentities($result->Name); ?>"><?php echo htmlentities($result->Name); ?></option>
<?php }} ?>
 </select>
 

 <p class="help-text text-danger">Please change this field (to the Packages current Location)</p>                                                        </div>
                                                    </div>



<div class="form-group">
<label for="default" class="col-sm-2 control-label">Cuurent Package Availability</label>
<div class="col-sm-10">
<select name="status" class="form-control" id="default" required="">
<option value="">Choose an Option</option>
<option value="Available">Available</option>
<option value="Not Available">Not Available</option>

 </select>
 <p class="help-text text-danger">Please select the package's current status (e.g Available, Not Available)</p>                                                        </div>
                                                    </div>

<div class="form-group">
<label for="default" class="col-sm-2 control-label">Cuurent State</label>
<div class="col-sm-10">
<select name="state" class="form-control" id="default" required="">
<option value="">Choose an Option</option>
<option value="Arrived">Arrived</option>
<option value="Not Arrived">Not Arrived</option>
<option value="Missing">Package Missing </option>


 </select>
 <p class="help-text text-danger">Please select the package's current state (e.g Arrived, Not Arrived, Package Missing)</p>     
                                                        </div>
                                                    </div>

<div class="form-group " hidden="">

   <label for="date" class="col-sm-2 control-label">Date</label>
            <div class="col-sm-10"> 
                <input type="text" name="dob" readonly="" class="form-control" id="date" value="<?php echo date("Y/m/d");?>">
            </div>
</div>
<?php }} ?>                                                    

                                                    
                                                    <div class="form-group">
                                                        <div class="col-sm-offset-2 col-sm-10">
                                                            <button type="submit" name="submit" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </div>
                                                </form>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-12 -->
                                </div>
                    </div>
                </div>
                <!-- /.content-container -->
            </div>
            <!-- /.content-wrapper -->
        </div>
        <!-- /.main-wrapper -->
        <script src="js/jquery/jquery-2.2.4.min.js"></script>
        <script src="js/bootstrap/bootstrap.min.js"></script>
        <script src="js/pace/pace.min.js"></script>
        <script src="js/lobipanel/lobipanel.min.js"></script>
        <script src="js/iscroll/iscroll.js"></script>
        <script src="js/prism/prism.js"></script>
        <script src="js/select2/select2.min.js"></script>
        <script src="js/main.js"></script>
        <script>
            $(function($) {
                $(".js-states").select2();
                $(".js-states-limit").select2({
                    maximumSelectionLength: 2
                });
                $(".js-states-hide").select2({
                    minimumResultsForSearch: Infinity
                });
            });
        </script>
    </body>
</html>
<?PHP } ?>
