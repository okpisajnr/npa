<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$dbname = "npa";
$mysqli = new mysqli($host, $dbuser, $dbpass, $dbname);

?>