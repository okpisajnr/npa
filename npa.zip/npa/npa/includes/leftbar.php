<div class="left-sidebar bg-black-300 box-shadow ">
                        <div class="sidebar-content">
                           

                            <div class="sidebar-nav">
                                <ul class="side-nav color-gray">
                                    <li class="nav-header">
                                        <span class="pull-center">Admin Category</span>
                                    </li>
                                    <li>
                                        <a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span> </a>
                                     
                                    </li>

                                    
                                    <li class="has-children">
                                        <a href="#"><i class="fa fa-globe"></i> <span>Country Sea Port</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <li><a href="create-class.php"><i class="fa fa-map"></i> <span>Create country</span></a></li>
                                            <li><a href="manage-country.php"><i class="fa fa fa-map"></i> <span>Manage country</span></a></li>
                                           
                                        </ul>
                                    </li>
  <li class="has-children">
                                        <a href="#"><i class="fa fa-anchor"></i> <span>Port</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <li><a href="create-subject.php"><i class="fa fa-ship"></i> <span>Create Port</span></a></li>
                                            <li><a href="manage-seaport.php"><i class="fa fa fa-ship"></i> <span>Manage Port</span></a></li>
                                           <li><a href="add-combination.php"><i class="fa fa-anchor"></i> <span>Add Port Combination </span></a></li>
                                           <a href="manage-combination.php"><i class="fa fa-anchor"></i> <span>Manage Port Combination </span></a></li>
                                        </ul>
                                    </li>
   <li class="has-children">
                                        <a href="#"><i class="fa fa-users"></i> <span>User</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            
                                            <li><a href="manage-user.php"><i class="fa fa fa-server"></i> <span>Manage User</span></a></li>

                                        </ul>
                                    </li>
<li class="has-children">
                                        <a href="#"><i class="fa fa-download"></i> <span>Import Package</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                        

  <li><a href="manage-import.php"><i class="fa fa-ship"></i> <span>Update Importations</span></a></li>
                                                                                     
                                        </ul>
                                      
                                        <li><a href="TransactionList.php"><i class="fa fa-money"></i> <span> Transaction List</span></a></li>
                                           
                                    </li>

                                        <li><a href="change-password.php"><i class="fa fa fa-server"></i> <span> Admin Change Password</span></a></li>
                                           
                                    </li>
                            </div>
                            <!-- /.sidebar-nav -->
                        </div>
                        <!-- /.sidebar-content -->
                    </div>