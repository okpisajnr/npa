<div class="left-sidebar bg-black-300 box-shadow ">
                        <div class="sidebar-content">
                            <div class="sidebar-nav">
                                <ul class="side-nav color-gray">
                                    <li class="nav-header">
                                       
                                        <a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>User's Dashboard</span> </a>
                                     
                                    </li>                                 
                                 <li><a href="updateprofile.php"><i class="fa fa fa-user"></i> <span> Update Profile</span></a></li>
                                 <li><a href="import.php"><i class="fa fa fa-download"></i> <span> Import Goods</span></a></li>
                        <li><a href="tracker.php"><i class="fa fa fa-eye"></i> <span> Tracker</span></a></li>
                          <li><a href="history.php"><i class="fa fa fa-list"></i> <span> Tracking History</span></a></li>
                        <li><a href="report.php"><i class="fa fa fa-server"></i> <span> Reports</span></a></li>

                                           
                          </ul>          
                            </div>
                            <!-- /.sidebar-nav -->
                        </div>
                        <!-- /.sidebar-content -->
                    </div>